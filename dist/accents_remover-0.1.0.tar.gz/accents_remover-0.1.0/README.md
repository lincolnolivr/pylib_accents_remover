# remove_accents-pylib
Function to remove accents without changing other types of characters