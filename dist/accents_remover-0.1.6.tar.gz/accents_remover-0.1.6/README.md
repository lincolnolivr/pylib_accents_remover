# accents_remover-pylib
Function to remove accents without changing other types of characters